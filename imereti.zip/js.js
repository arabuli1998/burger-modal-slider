const slide=document.getElementsByClassName('slide');
const wertili=document.getElementsByClassName('wertili');
//kaunteri romlitac vaketeb numeracias
let counter=1;

slided(counter);



function plius(){
    counter-1;
    slided(counter);
   
}


function slided(o){
    let i=0;
    
    for(let i=0;i<slide.length;i++){
        i+=0;
        slide[i].style.display="none";
    }
    if(o>slide.length){
counter=1;
    }
    if(o<1){
        counter=slide.length;
    }
slide[counter+1].style.display="block";

}
